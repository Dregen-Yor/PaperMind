# PaperMind Logo Kit

打开 [docs/brand/index.html](docs/brand/index.html) 查看三个方案，切换背景与尺寸并下载 SVG。预览页可直接在本地浏览器打开。

主方案为「问页 / Folio」，以打开内白的 P 连接论文阅读与提问，采用胡桃棕、象牙白和墨棕。

- [主标 SVG](assets/brand/papermind-logo.svg)
- [设计总览](docs/brand/index.png)
- [使用规范](docs/brand/README.md)
- [应用图标](assets/papermind-icon.png)
- [研究记录](docs/brand/research.md)

请保留文件夹结构，确保预览和文档中的相对链接正常。字标已转换为矢量路径，字体许可位于 assets/brand/SOURCE-SERIF-LICENSE.md。
